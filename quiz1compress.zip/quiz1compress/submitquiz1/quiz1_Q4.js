// quiz1_Q5

var n =0;
function double(n){

	for (i=1;i<=n;i++) {
		// console.log(i*2);
	return i*2;
		
	}
};


double(10);
