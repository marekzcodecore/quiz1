# quiz question 9


class Book
	attr_accessor :title
	attr_accessor :chapters
		


	#@title = ''
	#@chapters = []

	def initialize(title,chapters)
	 @title=title
	 @chapters=chapters
	end
	
	def add_chapter(chap)
		@chapters << chap
	end

	def chapters
	  i=0
	 puts "Your book: #{@title} has #{@chapters.length} chapters:"
	 #puts "#{@chapters.length}"
	 #puts "what"
	    
	   while i < @chapters.length do
	     	
	     puts "#{i+1}. #{@chapters[i]}"   
	     i =i + 1  
	    end
	end
end


booky = Book.new("haxs",["a"])
puts booky.chapters
booky.add_chapter("not the second chapter l")

puts booky.chapters
