// quiz1_Q3 is isPrime


// primetest

function isPrime(n) {
	console.log(n);
	 var prime = true;
	    for (var i=2;i<n;i++){
	      if (n%i==0){
	        prime = false;
		
	      }
  	      }
	    console.log(prime);
	    if (prime == true) {
	      console.log( n + " is prime");
	    } else {
	      console.log(n + " is not prime");
	    }
	    
}


isPrime(2372347);
isPrime(18);
