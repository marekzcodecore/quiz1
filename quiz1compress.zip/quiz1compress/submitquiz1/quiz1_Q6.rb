# quesion 7 ruby

module HelperMethods
	def self.titleize(sentence)
		exlude_words = ["in","the","of", "and","or","from" ]
		titled = [] 
		 sentence.split(' ').each do |word|
		  if exlude_words.include?(word) 
			titled << word
		  else
			titled << word.capitalize
		  end
		#  p titled   
		end
		p titled.join(' ')
	end
end

 HelperMethods.titleize("hello world and everyone on the earth") 	
