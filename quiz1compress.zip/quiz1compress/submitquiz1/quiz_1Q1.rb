## quiz 1

## 2. A stack is a list that gets executed last one in first one out. a que gets executed 
## first one in first one out. 



class Stack
	attr_accessor :my_arr
	def initialize 
	@my_arr = []
	end
	
	def add (a)
	 
		# puts "add element to end of array" 
		
		@my_arr << a		
	end


	def remove
		# puts " remove element from end of array"
		@my_arr.pop
		
	end


end


m = Stack.new


class Queue
	attr_accessor :my_arr
	def initialize 
	@my_arr = []
	end
	
	def add(a)
		
		# puts "add element to end of array"

		@my_arr << a
	end
		
	def remove
		# puts " remove element from front of array"
		@my_arr.shift
	end
end


m.add("a")
m.add("B")
puts m.add("c")

 m.remove
puts " "
puts m.my_arr

puts " "
q =Queue.new

q.add("a")
q.add("b")
q.add("c")

puts " "
puts q.my_arr

q.remove
puts " "
puts q.my_arr
