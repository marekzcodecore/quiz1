// quiz 1 q2


var prov = {};

prov = {BC:3,
	AB:2	
	};


for (var prop in prov) {
	console.log(prop + " has " + prov[prop] + " main cities");
	
}
