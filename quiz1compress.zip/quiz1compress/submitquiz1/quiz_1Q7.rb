# ruby question 8 quiz 1

module Blog

class Article
	attr_accessor :title
	attr_accessor :body
	
	def initialize(title,body) 

	@title= title
	@body= body
	
	end



	def get_body
	 @body
	end

	title = " the tale of a vogon"
	body = " stuff"
	module HelperMethods
	def self.titleize(sentence)
		exlude_words = ["in","the","of", "and","or","from" ]
		titled = [] 
		 sentence.split(' ').each do |word|
		  if exlude_words.include?(word) 
			titled << word
		  else
			titled << word.capitalize
		  end
		#  p titled   
		end
		 titled.join(' ')
	end
	end

	def get_title
	  HelperMethods.titleize(@title)
	end

end

class Snippet < Blog::Article

	attr_accessor :title
	attr_accessor :body

 	trunc = ''
	include HelperMethods

	def get_title
	   HelperMethods.titleize(@title)
	end

	def get_trunc
	 if body.length < 100 
		 @body
	 else 
	  trunc = @body[0..99] + "..."
	      trunc    
 	 end
	end
end

end



title = "spooky skeletons"
body = "this is the story all about how, my life got turned into a spooky skeleton 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 25 53 45 55 56 57 58 59 60 61 62 36 46 65 67 66 67 68 69 70 71 27 73 74 57 67 77 78 79 80 81 82 38 84 58 68 87 8 8 89 90"

book = Blog::Article.new(title,body)
puts book.get_title

puts book.get_body

snip = Blog::Snippet.new(title,body)

puts snip.get_title
puts snip.get_trunc
