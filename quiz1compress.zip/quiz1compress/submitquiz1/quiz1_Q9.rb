# question 10 ruby difference between include and extend.

module Base
	
	 def name_display
	  puts "display a name"
	 end

end


class B
	include Base
	puts " this includes class A from module Base" 	
end

class C
	extend Base
	 puts " this extends class A from module Base"
end
	
b = B.new.name_display

c = C.name_display
