// quiz1_Q5

var n =0;
function double(n){

	for (i=1;i<=n;i++) {

	return i*2;
	console.log(i*2);	
	}
};


double(10);
